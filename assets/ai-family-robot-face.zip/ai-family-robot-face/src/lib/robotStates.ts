export type RobotMode = 'fixed' | 'random' | 'auto';

export type RobotStateName =
  | 'neutral'
  | 'happy'
  | 'excited'
  | 'loving'
  | 'sad'
  | 'angry'
  | 'worried'
  | 'surprised'
  | 'confused'
  | 'thinking'
  | 'sleepy'
  | 'focused'
  | 'listening'
  | 'speaking'
  | 'celebrating'
  | 'alert'
  | 'error'
  | 'curious';

export type RobotStateConfig = {
  label: string;
  emoji: string;
  description: string;
  eyeGlow: number;
  lid: number;
  browTilt: number;
  mouthCurve: number;
  mouthOpen: number;
  mouthWidth: number;
  headTilt: number;
  headLift: number;
  scanSpeed: number;
  pulse: number;
};

export const ROBOT_STATES: Record<RobotStateName, RobotStateConfig> = {
  neutral:      { label: 'Neutral',      emoji: '◉', description: 'Calm default state',              eyeGlow: 1,   lid: 0,   browTilt: 0,    mouthCurve: 0,    mouthOpen: 0.08, mouthWidth: 1,    headTilt: 0,    headLift: 0,    scanSpeed: 7,   pulse: 1 },
  happy:        { label: 'Happy',        emoji: '😊', description: 'Warm, friendly and relaxed',       eyeGlow: 1.1, lid: 0,   browTilt: 0.08, mouthCurve: 0.8,  mouthOpen: 0.16, mouthWidth: 1.08, headTilt: -1,   headLift: -1,   scanSpeed: 6.5, pulse: 1.2 },
  excited:      { label: 'Excited',      emoji: '✨', description: 'High-energy positive reaction',   eyeGlow: 1.35,lid: -0.05,browTilt: -0.12,mouthCurve: 0.65, mouthOpen: 0.42, mouthWidth: 1.18, headTilt: 1.4,  headLift: -2.5, scanSpeed: 4.2, pulse: 1.7 },
  loving:       { label: 'Loving',       emoji: '💙', description: 'Affectionate, reassuring mode',   eyeGlow: 1.22,lid: 0.06,browTilt: 0.16, mouthCurve: 0.58, mouthOpen: 0.12, mouthWidth: 1.04, headTilt: -1.8, headLift: 0,    scanSpeed: 8,   pulse: 1.25 },
  sad:          { label: 'Sad',          emoji: '😔', description: 'Gentle concern and empathy',       eyeGlow: 0.75,lid: 0.38,browTilt: -0.22,mouthCurve: -0.62,mouthOpen: 0.05, mouthWidth: 0.96, headTilt: -2.2, headLift: 3,    scanSpeed: 10,  pulse: 0.75 },
  angry:        { label: 'Angry',        emoji: '😠', description: 'Strong negative reaction',         eyeGlow: 1.5, lid: -0.18,browTilt: 0.7, mouthCurve: -0.35,mouthOpen: 0.14, mouthWidth: 1.02, headTilt: 0.8, headLift: 0,    scanSpeed: 3.2, pulse: 1.9 },
  worried:      { label: 'Worried',      emoji: '😟', description: 'Uncertain or concerned',            eyeGlow: 0.92,lid: 0.24,browTilt: -0.46,mouthCurve: -0.28,mouthOpen: 0.07, mouthWidth: 0.96, headTilt: 1.7, headLift: 1.8,  scanSpeed: 8.5, pulse: 0.9 },
  surprised:    { label: 'Surprised',    emoji: '😮', description: 'Sudden discovery or shock',        eyeGlow: 1.65,lid: -0.12,browTilt: -0.55,mouthCurve: 0,    mouthOpen: 0.9,  mouthWidth: 0.82, headTilt: 0,    headLift: -3,   scanSpeed: 3.8, pulse: 1.8 },
  confused:     { label: 'Confused',     emoji: '🤔', description: 'Processing something unclear',     eyeGlow: 1.02,lid: 0.05,browTilt: -0.18,mouthCurve: 0.08, mouthOpen: 0.12, mouthWidth: 0.86, headTilt: 4.5,  headLift: 2,    scanSpeed: 6,   pulse: 1.05 },
  thinking:     { label: 'Thinking',     emoji: '🧠', description: 'Reasoning / planning',              eyeGlow: 1.0, lid: 0.12,browTilt: -0.1, mouthCurve: -0.02,mouthOpen: 0.05, mouthWidth: 0.92, headTilt: -3.5, headLift: 2.5,  scanSpeed: 4.8, pulse: 1.35 },
  sleepy:       { label: 'Sleepy',       emoji: '😴', description: 'Low-energy resting mode',            eyeGlow: 0.48,lid: 0.72,browTilt: 0.02, mouthCurve: 0.05, mouthOpen: 0.04, mouthWidth: 0.92, headTilt: -1.2, headLift: 4.5,  scanSpeed: 14,  pulse: 0.45 },
  focused:      { label: 'Focused',      emoji: '🎯', description: 'Concentrating on a task',           eyeGlow: 1.22,lid: -0.04,browTilt: 0.24, mouthCurve: 0,    mouthOpen: 0.06, mouthWidth: 0.94, headTilt: 0,    headLift: 0,    scanSpeed: 3.8, pulse: 1.5 },
  listening:    { label: 'Listening',    emoji: '👂', description: 'Waiting for the user',              eyeGlow: 1.2, lid: 0.08,browTilt: -0.06,mouthCurve: 0.04,mouthOpen: 0.03, mouthWidth: 0.96, headTilt: 0,    headLift: -1,   scanSpeed: 5.5, pulse: 1.25 },
  speaking:     { label: 'Speaking',     emoji: '🗣️', description: 'Lip-sync / speech mode',            eyeGlow: 1.18,lid: 0.02,browTilt: 0.05, mouthCurve: 0.18, mouthOpen: 0.52, mouthWidth: 1.08, headTilt: 0,    headLift: -0.4, scanSpeed: 5,   pulse: 1.25 },
  celebrating:  { label: 'Celebrating',  emoji: '🎉', description: 'Success or completed goal',        eyeGlow: 1.5, lid: -0.08,browTilt: -0.1,mouthCurve: 0.85, mouthOpen: 0.66, mouthWidth: 1.22, headTilt: -1.5, headLift: -3.5, scanSpeed: 3.8, pulse: 2.1 },
  alert:        { label: 'Alert',        emoji: '⚠️', description: 'Needs attention right now',        eyeGlow: 1.75,lid: -0.15,browTilt: 0.52, mouthCurve: -0.1,mouthOpen: 0.16, mouthWidth: 1.06, headTilt: 0,    headLift: -2,   scanSpeed: 2.2, pulse: 2.3 },
  error:        { label: 'Error',        emoji: '🛑', description: 'Something failed',                  eyeGlow: 1.9, lid: 0.06,browTilt: 0.55, mouthCurve: -0.58,mouthOpen: 0.18, mouthWidth: 1.04, headTilt: 0.9,  headLift: 1.5,  scanSpeed: 2.8, pulse: 2.6 },
  curious:      { label: 'Curious',      emoji: '🔎', description: 'Investigating or exploring',        eyeGlow: 1.28,lid: -0.02,browTilt: -0.26,mouthCurve: 0.12, mouthOpen: 0.1, mouthWidth: 0.97, headTilt: -2.8, headLift: -0.5, scanSpeed: 4.5, pulse: 1.45 },
};

export const RANDOM_STATES: RobotStateName[] = [
  'happy','excited','loving','sad','angry','worried','surprised','confused','thinking','sleepy','focused','listening','celebrating','alert','error','curious'
];

export function randomState(previous?: RobotStateName): RobotStateName {
  const candidates = RANDOM_STATES.filter((s) => s !== previous);
  return candidates[Math.floor(Math.random() * candidates.length)];
}
