import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import type { RobotMode, RobotStateName } from '../lib/robotStates';
import { ROBOT_STATES, randomState } from '../lib/robotStates';

type Props = {
  mode: RobotMode;
  state?: RobotStateName;
  onStateChange?: (state: RobotStateName) => void;
  speaking?: boolean;
  lipSyncLevel?: number;
};

const clamp = (n: number, min = 0, max = 1) => Math.min(max, Math.max(min, n));

export function RobotFace({ mode, state = 'neutral', onStateChange, speaking = false, lipSyncLevel = 0.4 }: Props) {
  const [blink, setBlink] = useState(false);
  const [randomStateValue, setRandomStateValue] = useState<RobotStateName>(() => randomState('neutral'));
  const [glance, setGlance] = useState({ x: 0, y: 0 });
  const [talkSeed, setTalkSeed] = useState(0);
  const lastBlink = useRef(0);

  const activeState = mode === 'fixed' ? state : mode === 'random' ? randomStateValue : (speaking ? 'speaking' : state);
  const cfg = ROBOT_STATES[activeState];
  const effectiveMouthOpen = speaking ? clamp(Math.max(cfg.mouthOpen, lipSyncLevel)) : cfg.mouthOpen;

  useEffect(() => {
    if (mode !== 'random') return;
    const id = window.setInterval(() => {
      setRandomStateValue((prev) => randomState(prev));
    }, 4200);
    return () => window.clearInterval(id);
  }, [mode]);

  useEffect(() => onStateChange?.(activeState), [activeState, onStateChange]);

  useEffect(() => {
    let timer: number;
    const schedule = () => {
      const now = Date.now();
      lastBlink.current = now;
      const delay = 2200 + Math.random() * 4200;
      timer = window.setTimeout(() => {
        setBlink(true);
        window.setTimeout(() => {
          setBlink(false);
          schedule();
        }, 120 + Math.random() * 90);
      }, Math.max(900, delay - (Date.now() - lastBlink.current)));
    };
    schedule();
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const id = window.setInterval(() => {
      setGlance({ x: (Math.random() - 0.5) * 9, y: (Math.random() - 0.5) * 5 });
    }, 1800 + Math.random() * 2200);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!speaking) return;
    const id = window.setInterval(() => setTalkSeed((s) => s + 1), 105 + Math.random() * 105);
    return () => window.clearInterval(id);
  }, [speaking]);

  const mouthPulse = useMemo(() => {
    const wobble = speaking ? ((talkSeed * 37) % 17) / 100 : 0;
    return clamp(effectiveMouthOpen + wobble);
  }, [effectiveMouthOpen, speaking, talkSeed]);

  const vars = {
    '--eye-glow': cfg.eyeGlow,
    '--lid': cfg.lid,
    '--brow': cfg.browTilt,
    '--mouth-curve': cfg.mouthCurve,
    '--mouth-open': mouthPulse,
    '--mouth-width': cfg.mouthWidth,
    '--head-tilt': `${cfg.headTilt}deg`,
    '--head-lift': `${cfg.headLift}px`,
    '--scan-speed': `${cfg.scanSpeed}s`,
    '--pulse': cfg.pulse,
    '--glance-x': `${glance.x}px`,
    '--glance-y': `${glance.y}px`,
  } as CSSProperties;

  const stateClass = `state-${activeState}`;
  return (
    <div className={`robot-face ${stateClass} ${blink ? 'is-blinking' : ''} ${speaking ? 'is-speaking' : ''}`} style={vars} aria-label={`AI face: ${ROBOT_STATES[activeState].label}`}>
      <img src="/assets/robot-guardian.png" alt="" className="robot-art" draggable={false} />
      <div className="robot-scanlines" />
      <div className="robot-particles" aria-hidden="true">
        {Array.from({ length: 22 }).map((_, i) => <i key={i} style={{ '--i': i } as CSSProperties} />)}
      </div>
      <svg className="robot-overlay" viewBox="0 0 1536 1536" role="presentation" aria-hidden="true">
        <defs>
          <filter id="cyanGlow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="10" result="blur" />
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
          <filter id="softGlow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
          <clipPath id="leftEyeClip"><ellipse cx="590" cy="606" rx="108" ry="61" /></clipPath>
          <clipPath id="rightEyeClip"><ellipse cx="946" cy="606" rx="108" ry="61" /></clipPath>
        </defs>

        <g className="eye-layer left-eye" style={{ transform: 'translate(var(--glance-x), var(--glance-y))' }}>
          <ellipse className="eye-mask" cx="590" cy="606" rx="112" ry="68" />
          <ellipse className="iris-ring" cx="590" cy="606" rx="44" ry="32" filter="url(#softGlow)" />
          <ellipse className="iris-core" cx="590" cy="606" rx="22" ry="18" filter="url(#cyanGlow)" />
          <circle className="eye-spec" cx="579" cy="596" r="7" />
          <path className="lid top" d="M478 606 Q590 520 702 606 Q590 550 478 606Z" />
          <path className="lid bottom" d="M478 606 Q590 694 702 606 Q590 663 478 606Z" />
        </g>

        <g className="eye-layer right-eye" style={{ transform: 'translate(var(--glance-x), var(--glance-y))' }}>
          <ellipse className="eye-mask" cx="946" cy="606" rx="112" ry="68" />
          <ellipse className="iris-ring" cx="946" cy="606" rx="44" ry="32" filter="url(#softGlow)" />
          <ellipse className="iris-core" cx="946" cy="606" rx="22" ry="18" filter="url(#cyanGlow)" />
          <circle className="eye-spec" cx="935" cy="596" r="7" />
          <path className="lid top" d="M834 606 Q946 520 1058 606 Q946 550 834 606Z" />
          <path className="lid bottom" d="M834 606 Q946 694 1058 606 Q946 663 834 606Z" />
        </g>

        <g className="brow-layer" aria-hidden="true">
          <path className="brow left" d="M486 518 Q590 470 684 520" />
          <path className="brow right" d="M852 520 Q946 470 1050 518" />
        </g>

        <g className="mouth-layer" aria-hidden="true">
          <rect className="mouth-mask" x="540" y="742" width="456" height="132" rx="60" />
          <path className="mouth-line" d="M568 805 Q768 805 968 805" />
          <path className="mouth-opening" d="M572 802 Q768 802 964 802 Q944 850 768 860 Q592 850 572 802Z" />
          <path className="mouth-teeth" d="M608 808 Q768 800 928 808 L910 826 Q768 836 626 826Z" />
          <circle className="mouth-energy left" cx="580" cy="815" r="8" />
          <circle className="mouth-energy right" cx="956" cy="815" r="8" />
        </g>

        <g className="chin-energy" filter="url(#softGlow)">
          <path d="M744 888 L792 888 L784 905 L752 905Z" />
        </g>
      </svg>

      <div className="state-chip"><span>{ROBOT_STATES[activeState].emoji}</span>{ROBOT_STATES[activeState].label}</div>
    </div>
  );
}
