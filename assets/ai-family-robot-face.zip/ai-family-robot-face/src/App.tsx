import { useMemo, useState } from 'react';
import { RobotFace } from './components/RobotFace';
import { ROBOT_STATES, type RobotMode, type RobotStateName } from './lib/robotStates';

export function App() {
  const [mode, setMode] = useState<RobotMode>('fixed');
  const [state, setState] = useState<RobotStateName>('neutral');
  const [text, setText] = useState('Good morning. I am ready to help your family.');
  const [speaking, setSpeaking] = useState(false);
  const [liveLip, setLiveLip] = useState(0.22);
  const [voice, setVoice] = useState<SpeechSynthesisVoice | null>(null);

  const states = useMemo(() => Object.entries(ROBOT_STATES) as [RobotStateName, (typeof ROBOT_STATES)[RobotStateName]][], []);

  const pickVoice = () => {
    const voices = window.speechSynthesis?.getVoices?.() ?? [];
    const preferred = voices.find(v => /^en/i.test(v.lang)) ?? voices.find(v => /^de/i.test(v.lang)) ?? voices[0] ?? null;
    setVoice(preferred);
    return preferred;
  };

  const speak = () => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const chosen = voice ?? pickVoice();
    if (chosen) utterance.voice = chosen;
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => { setSpeaking(false); setLiveLip(0.22); };
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const toggleSpeakingDemo = () => setSpeaking(v => !v);

  return (
    <main className="app-shell">
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">AI FAMILY • HOME SCREEN CHARACTER</div>
          <h1>Cyber Guardian</h1>
          <p className="lead">A persistent AI face designed for your family assistant: expressive, calm by default, state-driven when you need it, and capable of random emotional behavior.</p>

          <div className="panel">
            <div className="row-title">Mode</div>
            <div className="segmented">
              {(['fixed','random','auto'] as RobotMode[]).map(m => (
                <button key={m} className={mode === m ? 'active' : ''} onClick={() => setMode(m)}>{m === 'fixed' ? 'Fixed' : m === 'random' ? 'Random' : 'Auto'}</button>
              ))}
            </div>
            <div className="helper">
              {mode === 'fixed' && 'The face stays in the selected emotion until your application changes it.'}
              {mode === 'random' && 'The face cycles through varied emotions automatically.'}
              {mode === 'auto' && 'Your app can drive the state, while speaking temporarily takes over the mouth animation.'}
            </div>
          </div>

          <div className="panel">
            <div className="row-title">Emotion</div>
            <div className="state-grid">
              {states.map(([key, cfg]) => (
                <button key={key} className={state === key ? 'state-active' : ''} onClick={() => setState(key)}>
                  <span>{cfg.emoji}</span><span>{cfg.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="panel speech-panel">
            <div className="row-title">Speech / lip-sync demo</div>
            <textarea value={text} onChange={e => setText(e.target.value)} rows={3} />
            <div className="speech-actions">
              <button className="primary" onClick={speak}>Speak with browser TTS</button>
              <button onClick={toggleSpeakingDemo}>{speaking ? 'Stop mouth animation' : 'Animate speaking'}</button>
            </div>
            <label className="range-row">Mouth level <input type="range" min="0" max="1" step="0.01" value={liveLip} onChange={e => setLiveLip(Number(e.target.value))} /></label>
          </div>
        </div>

        <div className="face-stage">
          <RobotFace mode={mode} state={state} speaking={speaking} lipSyncLevel={liveLip} />
          <div className="stage-caption">
            <div><strong>Default</strong><span>Neutral / friendly</span></div>
            <div><strong>State API</strong><span>fixed • random • auto</span></div>
            <div><strong>Runtime</strong><span>React + SVG overlays</span></div>
          </div>
        </div>
      </section>

      <section className="integration">
        <div>
          <div className="eyebrow">DROP-IN CONTRACT</div>
          <h2>Designed for Claude Code integration</h2>
          <p>Your real application can call a single controller instead of knowing anything about the SVG internals.</p>
        </div>
        <pre>{`// Example controller contract
setAiFace({ mode: 'fixed', state: 'happy' });
setAiFace({ mode: 'fixed', state: 'angry' });
setAiFace({ mode: 'random' });
setAiFace({ mode: 'auto', state: 'neutral' });
setAiFace({ speaking: true, lipSyncLevel: 0.72 });`}</pre>
      </section>
    </main>
  );
}
