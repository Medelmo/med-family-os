// Copy the state contract into your existing AI Family app.

// Default home screen: calm/friendly.
const defaultFace = { mode: 'fixed' as const, state: 'neutral' as const };

// Successful action.
const successFace = { mode: 'fixed' as const, state: 'celebrating' as const };

// Assistant is listening.
const listeningFace = { mode: 'fixed' as const, state: 'listening' as const };

// Assistant is speaking. Keep the semantic state and drive the mouth from audio.
const speakingFace = {
  mode: 'auto' as const,
  state: 'happy' as const,
  speaking: true,
  lipSyncLevel: 0.72,
};

// Ambient/random mode.
const ambientFace = { mode: 'random' as const };
