# Claude Code integration instructions

Do not redraw this character with CSS/SVG from scratch.

Use `RobotFace` as the visual implementation and keep the application logic separate.

## State contract

```ts
type RobotMode = 'fixed' | 'random' | 'auto';

type RobotStateName =
  | 'neutral' | 'happy' | 'excited' | 'loving'
  | 'sad' | 'angry' | 'worried' | 'surprised'
  | 'confused' | 'thinking' | 'sleepy' | 'focused'
  | 'listening' | 'speaking' | 'celebrating'
  | 'alert' | 'error' | 'curious';
```

## Recommended app rules

- On normal home-screen operation, use `neutral` or `happy`.
- When the assistant is listening, use `listening`.
- While the TTS stream plays, set `speaking=true` and feed an audio-derived `lipSyncLevel` from 0..1.
- For task success, use `celebrating` briefly and then return to `happy` or `neutral`.
- For warnings, use `worried` or `alert`.
- For failures, use `error` and show the application's error message as the authoritative source of truth.
- For user prompts requiring thought/latency, use `thinking`.
- For exploratory/lookup operations, use `curious`.
- Never infer the emotional state from sensitive personal information. State transitions should be deterministic business/UI events.

## Random mode

Random mode is intended for ambient character behavior, not for conveying system status. Never use random mode to communicate errors, deadlines, or other important information because it can select an emotionally misleading state.

## Later Rive migration

Keep the state names and conceptual parameters stable. A future Rive state machine can expose equivalent inputs such as:

- `state` trigger / enum bridge
- `speaking` boolean
- `lipSyncLevel` number
- `blink` trigger
- `intensity` number

This preserves the integration boundary.
