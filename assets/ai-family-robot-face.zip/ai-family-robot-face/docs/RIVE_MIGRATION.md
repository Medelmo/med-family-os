# Optional Rive migration

The current project is intentionally zero-Rive at runtime so the supplied prototype works without a `.riv` binary.

Rive has an official React runtime. At the time this package was prepared, `@rive-app/react-canvas` was version 4.34.2 and `@rive-app/canvas` was 2.42.1 in npm's current release listings. These packages expose TypeScript declarations and state-machine-oriented runtime APIs.

When the character artwork is finalized, the current `RobotStateName` values should map 1:1 to Rive state-machine inputs. Keep `speaking`, `lipSyncLevel` and `blink` as separate inputs so the AI application does not depend on Rive implementation details.
