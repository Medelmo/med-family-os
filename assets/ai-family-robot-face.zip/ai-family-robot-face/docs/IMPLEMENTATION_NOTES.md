# Implementation notes

The reference stock image supplied by the user is watermarked. It is not embedded in this project.

The bundled robot artwork is a newly generated sci-fi character created for this project. The face animation is implemented as layered SVG overlays over that artwork so the character can blink, glance, change mouth shape, and react to state without generating a new video for every utterance.

This project intentionally does not bundle a `.riv` file because a Rive state machine must be authored/exported in the Rive editor. The state API is deliberately kept Rive-friendly so the current prototype can be replaced by a Rive asset later without changing the application's high-level state contract.
