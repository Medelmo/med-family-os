# AI Family – Cyber Guardian Robot Face

A drop-in React/Vite prototype for the AI Family home-screen character.

## What is included

- Photorealistic original cybernetic robot artwork generated for this prototype.
- SVG overlays for independently animated eyes, eyelids, eyebrows, mouth and energy accents.
- 18 expressive states:
  `neutral`, `happy`, `excited`, `loving`, `sad`, `angry`, `worried`, `surprised`, `confused`, `thinking`, `sleepy`, `focused`, `listening`, `speaking`, `celebrating`, `alert`, `error`, `curious`.
- Modes:
  - `fixed`: explicit state chosen by the app.
  - `random`: automatically changes to a different expressive state every few seconds.
  - `auto`: app-controlled state with speaking taking over mouth animation.
- Automatic blinking with randomized intervals.
- Small eye glances, scanning, energy pulses and state-specific motion.
- Speech demo using the browser Web Speech API.
- Lip-sync level input. Connect this to real audio analysis in your production app.

## Run

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Production integration

The reusable visual component is `src/components/RobotFace.tsx` and the state contract is `src/lib/robotStates.ts`.

Your application should keep AI/business logic outside the component and only pass a small visual state contract:

```ts
<RobotFace
  mode="fixed"
  state="happy"
  speaking={isSpeaking}
  lipSyncLevel={0.68}
/>
```

For a future Rive migration, keep the same state names and parameters. This lets the current SVG runtime be replaced by a `.riv` state machine without changing the AI-facing application contract.
